(function($) {

	XenForo.timelineBlock = function($block) { this.__construct($block); };
	XenForo.timelineBlock.prototype =
	{
		__construct: function($block)
		{
			$this = this;
			this.$block = $block;
			$block.find('.timelineImg').click($.context(this, 'openContent'));
			this.$target = $block.attr('data-target');

			$block.hover(function(){
				if(!$block.hasClass('active')){
					$('.timelineList').addClass('onHover');
				}
			}, function(){
				if(!$block.hasClass('active')){
					$('.timelineList').removeClass('onHover');
				}
			});
		},
		openContent: function(e)
		{
			e.preventDefault();
			$this = this;
			if(!this.$block.hasClass('active')){
				$('.timelineBlock.active').removeClass('active');
				this.$block.addClass('active');
				var $target = $('.cd-container').find('.cd-timeline-block.' + this.$target);
				if(!$target.hasClass('active')){
					$('.cd-container').find('.cd-timeline-block.active').removeClass('active');
					$target.addClass('active');
					var $container = $('.home-gallery ul.gallery');
						$container.isotope({
						filter: '*',
						animationOptions: {
						duration: 250,
						easing: 'linear',
						queue: false
						}
					});
				}
			}

		}
	};
	XenForo.cdTimelineBlock = function($block) { this.__construct($block); };
	XenForo.cdTimelineBlock.prototype =
	{
		__construct: function($block)
		{
			$this = this;
			this.$block = $block;
			$block.find('.readMore').click($.context(this, 'openContent'));
			this.$target = $block.attr('data-target');
		},
		openContent: function(e)
		{
			e.preventDefault();
			$this = this;
			this.$block.find('.readMore').addClass('hide');
			this.$block.find('.blockContent').addClass('show');
		}
	};
	XenForo.cdTimeline = function($container) { this.__construct($container); };
	XenForo.cdTimeline.prototype =
	{
		__construct: function($container)
		{
			var $this = this;
			this.$container = $container;
			$(window).on('resize', $.context(this, 'ajustSize'));
			this.ajustSize();
		},

		ajustSize: function(e)
		{
			var width = parseInt($(window).innerWidth());
			if(width <= 768){
				if(!this.$container.hasClass('small')){
					this.$container.addClass('small');
					this.reOrder();
				}
			}else{
				if(this.$container.hasClass('small')){
					this.$container.removeClass('small');
					this.reOrder();
				}
			}
		},

		reOrder: function(e)
		{
			var smallContainer = $('.timelineList .container');
			smallContainer.find('.timelineBlock').each(function() {
				$(this).prependTo(smallContainer);
			});
			var cdTimeline = $('#cd-timeline');
			cdTimeline.find('.cd-timeline-block').each(function() {
				$(this).prependTo(cdTimeline);
			});
		}
	};


	XenForo.register('.timelineBlock', 'XenForo.timelineBlock');
	XenForo.register('.cd-timeline-block', 'XenForo.cdTimelineBlock');
	XenForo.register('#cd-timeline', 'XenForo.cdTimeline');

	$(function() {
		$('.fancybox-thumbs').click(function(e){
			e.preventDefault();
		});
		$('.fancybox-thumbs').fancybox({
			prevEffect : 'none',
			nextEffect : 'none',

			closeBtn  : false,
			arrows    : false,
			nextClick : true,

			helpers : {
				thumbs : {
					width  : 50,
					height : 50
				}
			}
		});
	});


})(jQuery);